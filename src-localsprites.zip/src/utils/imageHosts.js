// src/utils/imageHosts.js
//
// Resolves sprite URLs with this priority:
// 1) Local map (public/drive_cache_local.json) → "/sprites/<key>.<ext>"
// 2) Explicit local path in meta.sprite or meta.src (if starts with "/sprites/")
// 3) Heuristic local path "/sprites/<key>.png"
// 4) Remote (drive_cache/url/image/thumb/sprite), with gimg proxy for lh3.googleusercontent.com
//
// Usage:
//   import { spriteUrlFromMeta, spriteUrlFromKey } from "../utils/imageHosts";
//   const url = spriteUrlFromMeta(match?.ref || match?.meta);

const RE_GIMG = /^https?:\/\/lh3\.googleusercontent\.com\//i;

// ---- tiny lazy loader for the local cache map ----
let _localIndexPromise = null;
let _localMap = null; // Map<key, "/sprites/<key>.<ext>">

function normalizeCacheShape(raw) {
  // Accepts array [{key, src/name/url}] or dict {key: {src/name/url}}
  const m = new Map();
  if (Array.isArray(raw)) {
    for (const e of raw) {
      const key = String(e?.key || "").trim();
      const src = e?.src || e?.sprite || e?.url || e?.drive_cache || "";
      if (key && typeof src === "string" && src.startsWith("/")) {
        m.set(key, src);
      }
    }
  } else if (raw && typeof raw === "object") {
    for (const [keyRaw, v] of Object.entries(raw)) {
      const key = String(keyRaw).trim();
      const src = v?.src || v?.sprite || v?.url || v?.drive_cache || "";
      if (key && typeof src === "string" && src.startsWith("/")) {
        m.set(key, src);
      }
    }
  }
  return m;
}

export function ensureLocalCacheLoaded() {
  if (_localIndexPromise) return _localIndexPromise;
  _localIndexPromise = (async () => {
    try {
      const res = await fetch("/drive_cache_local.json", { cache: "no-store" });
      if (!res.ok) return null; // file may not exist yet
      const json = await res.json();
      _localMap = normalizeCacheShape(json);
      if (_localMap && _localMap.size) {
        console.log(`[sprites] local cache loaded: ${_localMap.size} entries`);
      }
    } catch {
      _localMap = null;
    }
    return _localMap;
  })();
  return _localIndexPromise;
}

// fire-and-forget load (doesn't block)
if (typeof window !== "undefined") {
  // eslint-disable-next-line @typescript-eslint/no-floating-promises
  ensureLocalCacheLoaded();
}

// ---- helpers ----
export function proxifyGoogleusercontent(url) {
  if (!url) return "";
  if (RE_GIMG.test(url)) {
    try {
      const u = new URL(url);
      return "/gimg" + u.pathname + (u.search || "");
    } catch {
      return url.replace(RE_GIMG, "/gimg/");
    }
  }
  return url;
}

function pickRemote(meta) {
  return (
    meta?.drive_cache ||
    meta?.url ||
    meta?.image ||
    meta?.thumb ||
    meta?.sprite ||
    meta?.src ||
    ""
  );
}

function keyOf(meta) {
  return (
    meta?.key ||
    meta?.id ||
    // some datasets tuck "ref" under meta
    meta?.ref?.key ||
    meta?.ref?.id ||
    ""
  );
}

// ---- public API ----
export function spriteUrlFromKey(key) {
  if (!key) return "";
  // 1) exact local match if we’ve loaded the map
  if (_localMap && _localMap.has(key)) return _localMap.get(key);

  // 2) optimistic local guess (PNG by convention)
  return `/sprites/${key}.png`;
}

export function spriteUrlFromMeta(meta) {
  // 0) explicit local path baked in
  const explicit = meta?.sprite || meta?.src;
  if (typeof explicit === "string" && explicit.startsWith("/sprites/")) {
    return explicit;
  }

  // 1) local map (authoritative)
  const k = keyOf(meta);
  if (k && _localMap && _localMap.has(k)) {
    return _localMap.get(k);
  }

  // 2) optimistic local guess
  if (k) {
    return `/sprites/${k}.png`;
  }

  // 3) remote fallback (proxified if lh3)
  const remote = pickRemote(meta);
  return proxifyGoogleusercontent(remote);
}

// Convenience for match objects: spriteUrlFromMatch(match)
export function spriteUrlFromMatch(match) {
  // prefer ref/meta objects if present
  const meta = match?.ref || match?.meta || match;
  return spriteUrlFromMeta(meta);
}
