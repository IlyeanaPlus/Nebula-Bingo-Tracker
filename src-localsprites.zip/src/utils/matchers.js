// src/utils/matchers.js
import { tuning } from "../tuning/tuningStore";

/** Prefer drive_cache, then other common fields */
export function pickSpriteUrl(ref) {
  return (
    ref?.drive_cache ||
    ref?.sprite ||
    ref?.url ||
    ref?.image ||
    ref?.thumb ||
    ref?.path ||
    ref?.ref?.url ||
    null
  );
}

function l2norm(v) {
  let s = 0.0;
  for (let i = 0; i < v.length; i++) s += v[i] * v[i];
  if (s <= 0) return v;
  const inv = 1 / Math.sqrt(s);
  const out = new Float32Array(v.length);
  for (let i = 0; i < v.length; i++) out[i] = v[i] * inv;
  return out;
}

function dotSameLen(a, b) {
  let s = 0.0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}

/** Create a view over the index vectors with on-the-fly dimension adaptation */
function makeIndexView(index) {
  const metaCount =
    (Array.isArray(index?.meta) && index.meta.length) ||
    (Array.isArray(index?.vectors) ? index.vectors.length : 0);

  // Case A: vectors = Array<Array<number|float>>
  if (Array.isArray(index?.vectors)) {
    const dim = index.vectors[0]?.length || 0;
    return {
      dim,
      count: index.vectors.length,
      /** Return a Float32Array of length targetDim (truncate or zero-pad) */
      at: (i, targetDim) => {
        const v = index.vectors[i];
        if (!v) return null;
        if (!targetDim || v.length === targetDim) {
          // Ensure Float32Array
          return v instanceof Float32Array ? v : new Float32Array(v);
        }
        const len = Math.min(targetDim, v.length);
        const out = new Float32Array(targetDim);
        // copy first len components
        for (let k = 0; k < len; k++) out[k] = v[k];
        // zero-pad remainder if any
        return out;
      },
    };
  }

  // Case B: vectors = Float32Array laid out [row-major]
  const buf = index?.vectors;
  if (buf instanceof Float32Array && metaCount > 0) {
    const dim = Math.floor(buf.length / metaCount) || 0;
    return {
      dim,
      count: metaCount,
      at: (i, targetDim) => {
        const start = i * dim;
        const end = start + dim;
        let v = buf.subarray(start, end);
        if (!targetDim || v.length === targetDim) return v;
        const len = Math.min(targetDim, v.length);
        const out = new Float32Array(targetDim);
        out.set(v.subarray(0, len), 0); // truncate/pad
        return out;
      },
    };
  }

  // Fallback empty view
  return { dim: 0, count: 0, at: () => null };
}

/**
 * Find best match with adaptive-dimension dot product.
 * Returns { bestIdx, score, ref, spriteUrl } | null
 */
export function findBestMatch(query, index, threshold) {
  if (!query || !index) return null;

  const th = typeof threshold === "number" ? threshold : Number(tuning.get()?.scoreThreshold ?? 0.28);
  const view = makeIndexView(index);
  if (!view.count) return null;

  const q = index.normalized ? query : l2norm(query);
  const qDim = q.length;

  // One-time dev hint if dims differ
  if (import.meta?.env?.DEV && view.dim !== qDim) {
    console.warn(
      "[matchers] dimension mismatch: query", qDim, "index", view.dim,
      "→ trunc/pad to", qDim
    );
  }

  let bestIdx = -1;
  let bestScore = -Infinity;

  for (let i = 0; i < view.count; i++) {
    const v = view.at(i, qDim);
    if (!v || v.length !== qDim) continue;
    const score = dotSameLen(q, v);
    if (score > bestScore) {
      bestScore = score;
      bestIdx = i;
    }
  }

  if (bestIdx < 0 || !Number.isFinite(bestScore) || bestScore < th) return null;

  const ref = (Array.isArray(index.meta) && index.meta[bestIdx]) || {};
  const spriteUrl = pickSpriteUrl(ref);

  if (!spriteUrl && import.meta?.env?.DEV) {
    console.warn("[matchers] best match has no sprite url", { bestIdx, score: bestScore, ref });
  }

  return { bestIdx, score: bestScore, ref, spriteUrl };
}
