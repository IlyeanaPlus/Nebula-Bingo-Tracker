// src/utils/sprites.js
export async function getSpriteIndex() {
  const res = await fetch("/sprite_index_clip.json", { cache: "no-store" });
  if (!res.ok) throw new Error(`Failed to load sprite index: ${res.status}`);
  const j = await res.json();

  // --- New row-wise base64 format ---
  if (Array.isArray(j.items) && (j.dim | 0)) {
    const dim = j.dim | 0;
    const N = j.items.length;
    const M = new Float32Array(N * dim);
    const meta = new Array(N);

    const b642f32 = (b64) => {
      const bin = atob(b64);
      const buf = new ArrayBuffer(bin.length);
      const u8 = new Uint8Array(buf);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return new Float32Array(buf);
    };

    for (let i = 0; i < N; i++) {
      const it = j.items[i];
      let row;
      if (it.vector_b64) row = b642f32(it.vector_b64);
      else if (Array.isArray(it.vector)) row = new Float32Array(it.vector);
      else throw new Error(`Row ${i} missing vector_b64/vector`);
      if (row.length !== dim) throw new Error(`Row ${i} has dim=${row.length}, expected ${dim}`);
      M.set(row, i * dim);
      meta[i] = {
        key: it.key ?? String(i + 1),
        name: it.name ?? it.key ?? String(i + 1),
        drive_cache: it.drive_cache ?? it.url ?? "",
        sprite: it.sprite ?? ""
      };
    }

    console.log("[sprites] loaded index (rows/base64):", { entries: N, dim });
    return { dim, count: N, vectors: M, meta, normalized: true };
  }

  // --- Backward compat: flat/rows formats ---
  if (Array.isArray(j.vectors) && (j.dim | 0)) {
    const dim = j.dim | 0;
    const count = j.count ?? (j.meta?.length ?? Math.floor(j.vectors.length / dim));
    return {
      dim, count,
      vectors: new Float32Array(j.vectors),
      meta: j.meta ?? Array.from({ length: count }, (_, i) => ({ key: String(i + 1) })),
      normalized: true
    };
  }

  throw new Error("[sprites] Unrecognized sprite index format.");
}
