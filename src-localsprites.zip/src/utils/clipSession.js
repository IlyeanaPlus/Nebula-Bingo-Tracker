// src/utils/clipSession.js
// ORT JSEP wiring + tile preprocessing:
// - Prefer a base directory for wasmPaths (keeps .mjs ↔ .wasm in lockstep).
// - Filename map as a fallback (aliases included).
// - Unboarding step (trim uniform borders) before imageToClipTensor.
// - Create session from bytes; fallback to URL.
// - Export: getClipSession, embedImage, setClipModelUrl, l2norm.

import ort, { ORT_EXECUTION_PROVIDERS } from "../utils/ortEnv";
import { resolvePublic } from "./publicPath";
import { imageToClipTensor } from "./clip";
import { tuning } from "../tuning/tuningStore";

let _session = null;
let _modelUrl = resolvePublic("models/vision_model_int8_qlinear.onnx");
let _modelBytes = null;

export function setClipModelUrl(url) {
  _modelUrl = url;
  _session = null;
  _modelBytes = null;
}

const strip = (u) => (u ? u.split("#")[0].split("?")[0] : "");

/** Derive a base directory (ending with "/") from the emitted asset URLs. */
function getEmittedBaseDir() {
  const mjs = strip(window.__ORT_JSEP_MJS_EMITTED__ || "");
  const wasm = strip(window.__ORT_WASM_EMITTED__ || "");
  const any = mjs || wasm;
  if (!any) return null;
  try {
    const abs = new URL(any, document.baseURI).href;
    return abs.slice(0, abs.lastIndexOf("/") + 1); // ensure trailing slash
  } catch {
    return null;
  }
}

/** Prefer a single base directory string for ORT’s JSEP assets. */
function ensureWasmBaseDir() {
  const base = getEmittedBaseDir();
  if (!base) return false;
  const cur = ort.env.wasm.wasmPaths;
  if (typeof cur !== "string" || cur !== base) {
    ort.env.wasm.wasmPaths = base;
    console.log("[clipSession] wasmPaths base →", base);
  }
  return true;
}

/** Optional: filename map (aliases included) as a fallback. */
function ensureWasmFilenameMap() {
  const wasm = strip(window.__ORT_WASM_EMITTED__ || "");
  const mjs  = strip(window.__ORT_JSEP_MJS_EMITTED__ || "");
  if (!wasm && !mjs) return;

  const map = {};
  if (mjs)  map["ort-wasm-simd-threaded.jsep.mjs"]  = mjs;
  if (wasm) map["ort-wasm-simd-threaded.jsep.wasm"] = wasm;

  // Safety aliases
  if (wasm) {
    map["ort-wasm-simd-threaded.wasm"] = wasm;
    map["ort-wasm-simd.wasm"]          = wasm;
    map["ort-wasm-threaded.wasm"]      = wasm;
    map["ort-wasm.wasm"]               = wasm;
  }
  if (mjs) {
    map["ort-wasm-simd.jsep.mjs"]      = mjs;
    map["ort-wasm-threaded.jsep.mjs"]  = mjs;
    map["ort-wasm.jsep.mjs"]           = mjs;
  }

  const prev = typeof ort.env.wasm.wasmPaths === "object" ? ort.env.wasm.wasmPaths : null;
  const same =
    prev &&
    Object.keys(map).length === Object.keys(prev).length &&
    Object.keys(map).every((k) => prev[k] === map[k]);

  if (!same) {
    ort.env.wasm.wasmPaths = map;
    console.log("[clipSession] wasmPaths map →", map);
  }
}

/** Ensure ORT knows where the loader + wasm live (base dir first, map second). */
function ensureWasmPaths() {
  const ok = ensureWasmBaseDir();
  if (!ok) ensureWasmFilenameMap();
}

// Run once on module load; harmless if globals aren’t set yet.
ensureWasmPaths();

/** ---- Unboarding: trim uniform border before embedding ----
 * eps ∈ [0..1] → per-channel tolerance (0=no-op). We limit trim to ≤15% per side.
 */
function unboardCanvas(input, eps = 0, maxFrac = 0.15) {
  if (!input || !eps || eps <= 0) return input;

  const w = input.width | 0;
  const h = input.height | 0;
  if (w < 8 || h < 8) return input;

  const thr = Math.max(0, Math.min(1, eps)) * 255;
  const maxPxX = Math.floor(maxFrac * w);
  const maxPxY = Math.floor(maxFrac * h);

  const src = input;
  const ctx = (src.getContext && src.getContext("2d")) ? src.getContext("2d") : null;
  if (!ctx) return input;

  const id = ctx.getImageData(0, 0, w, h);
  const data = id.data;

  // Corner color = avg of 4 corners (2x2 each to be robust)
  function sample(px, py) {
    const i = (py * w + px) * 4;
    return [data[i], data[i+1], data[i+2]];
  }
  const corners = [
    sample(0, 0), sample(1, 0), sample(0, 1), sample(1, 1),
    sample(w-1, 0), sample(w-2, 0), sample(w-1, 1), sample(w-2, 1),
    sample(0, h-1), sample(1, h-1), sample(0, h-2), sample(1, h-2),
    sample(w-1, h-1), sample(w-2, h-1), sample(w-1, h-2), sample(w-2, h-2),
  ];
  let r=0,g=0,b=0;
  for (const c of corners) { r+=c[0]; g+=c[1]; b+=c[2]; }
  r/=corners.length; g/=corners.length; b/=corners.length;

  const close = (R,G,B) =>
    Math.abs(R - r) <= thr && Math.abs(G - g) <= thr && Math.abs(B - b) <= thr;

  // Scan helpers
  function rowIsClose(y) {
    const base = y * w * 4;
    let ok = 0;
    for (let x=0; x<w; x++) {
      const i = base + x*4;
      if (close(data[i], data[i+1], data[i+2])) ok++;
    }
    // consider row border if ≥90% pixels are within eps
    return ok >= 0.9 * w;
  }
  function colIsClose(x) {
    let ok = 0;
    for (let y=0; y<h; y++) {
      const i = (y * w + x) * 4;
      if (close(data[i], data[i+1], data[i+2])) ok++;
    }
    return ok >= 0.9 * h;
  }

  let top=0, bottom=h-1, left=0, right=w-1;
  while (top < Math.min(maxPxY, h-8) && rowIsClose(top)) top++;
  while (bottom > h-1-Math.min(maxPxY, h-8) && rowIsClose(bottom)) bottom--;
  while (left < Math.min(maxPxX, w-8) && colIsClose(left)) left++;
  while (right > w-1-Math.min(maxPxX, w-8) && colIsClose(right)) right--;

  // Keep sane minimum
  if (right - left < 8 || bottom - top < 8) return input;

  // Fast path: nothing trimmed
  if (top === 0 && left === 0 && right === w-1 && bottom === h-1) return input;

  const cw = right - left + 1;
  const ch = bottom - top + 1;
  const out = document.createElement("canvas");
  out.width = w; out.height = h;
  const octx = out.getContext("2d");
  // Draw trimmed region back to original size (letterbox removal)
  octx.drawImage(src, left, top, cw, ch, 0, 0, w, h);
  return out;
}

/** Memoized session creator; prefers bytes, falls back to URL. */
export async function getClipSession(opts = {}) {
  if (_session) return _session;
  ensureWasmPaths();
  console.log("[clipSession] using wasmPaths:", ort.env.wasm.wasmPaths);

  const defaultOpts = {
    executionProviders: ORT_EXECUTION_PROVIDERS, // ["wasm"]
    graphOptimizationLevel: "all",
  };

  if (!_modelBytes) {
    console.log("[clipSession] fetching model bytes:", _modelUrl);
    const res = await fetch(_modelUrl, { cache: "no-store" });
    const bytes = await res.arrayBuffer();
    _modelBytes = bytes;
    console.log("[clipSession] model bytes fetched:", bytes.byteLength, "bytes");
  }

  console.log("[clipSession] creating session from bytes…");
  try {
    _session = await ort.InferenceSession.create(_modelBytes, {
      ...defaultOpts,
      ...opts,
    });
    return _session;
  } catch (e) {
    console.warn("[clipSession] byte session failed, falling back to URL:", e);
    _session = await ort.InferenceSession.create(_modelUrl, {
      ...defaultOpts,
      ...opts,
    });
    return _session;
  }
}

/** embedImage(imgLike, session?) -> Float32Array(512, L2-normalized) */
export async function embedImage(imgLike, session) {
  const s = session || (await getClipSession());

  const { unboardEps /*, scoreThreshold, cropJitter */ } = tuning.get();

  // Optional unboarding (trim uniform border) before tensorization
  let input = imgLike;
  if (unboardEps && typeof unboardEps === "number" && unboardEps > 0) {
    input = unboardCanvas(imgLike, unboardEps, 0.15);
  }

  // Preprocess → tensor (NCHW Float32, 224)
  const { data, shape } = await imageToClipTensor(input, 224);
  const inputName = (s.inputNames && s.inputNames[0]) || "input";
  const feeds = { [inputName]: new ort.Tensor("float32", data, shape) };

  const results = await s.run(feeds);
  const outName = (s.outputNames && s.outputNames[0]) || Object.keys(results)[0];
  const out = results[outName];

  // Extract first vector robustly
  let vec;
  const raw  = out && out.data;
  const dims = out && out.dims;

  if (raw instanceof Float32Array) {
    if (Array.isArray(dims) && dims.length === 2 && dims[0] === 1) {
      vec = new Float32Array(dims[1]);
      vec.set(raw.subarray(0, dims[1]));
    } else {
      vec = raw;
    }
  } else if (raw && raw.buffer) {
    const f = raw instanceof Float32Array ? raw : new Float32Array(raw);
    if (Array.isArray(dims) && dims.length === 2 && dims[0] === 1) {
      vec = new Float32Array(dims[1]);
      vec.set(f.subarray(0, dims[1]));
    } else {
      vec = f;
    }
  } else {
    throw new Error("Unexpected CLIP output tensor");
  }

  return l2norm(vec);
}

export function l2norm(vec) {
  let sum = 0.0;
  for (let i = 0; i < vec.length; i++) sum += vec[i] * vec[i];
  const inv = sum > 0 ? 1.0 / Math.sqrt(sum) : 0;
  const out = new Float32Array(vec.length);
  for (let i = 0; i < vec.length; i++) out[i] = vec[i] * inv;
  return out;
}
