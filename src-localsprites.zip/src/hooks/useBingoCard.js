// src/hooks/useBingoCard.js
import { useRef, useState } from "react";
import { fileToImage, computeCrops25 } from "../utils/image";
import { getClipSession, embedImage } from "../utils/clipSession";
import { getSpriteIndex } from "../utils/sprites";
import { findBestMatch } from "../utils/matchers";
import { tuning } from "../tuning/tuningStore";

/** Cache the sprite index across cards */
let spriteIndexPromise = null;
async function ensureSpriteIndex() {
  if (!spriteIndexPromise) spriteIndexPromise = getSpriteIndex();
  return spriteIndexPromise;
}
const log = (...a) => console.log(...a);

/** ---- sprite URL resolver w/ googleusercontent proxy ---- */
const RE_GIMG = /^https?:\/\/lh3\.googleusercontent\.com\//i;
function proxifyGoogleusercontent(url) {
  if (!url) return "";
  if (!RE_GIMG.test(url)) return url;
  try {
    const u = new URL(url);
    return "/gimg" + u.pathname + (u.search || "");
  } catch {
    return url.replace(RE_GIMG, "/gimg/");
  }
}
function spriteUrlFromMeta(meta) {
  const raw =
    meta?.drive_cache || meta?.url || meta?.image || meta?.thumb || meta?.sprite || "";
  const proxied = proxifyGoogleusercontent(raw);
  if (proxied) return proxied;
  if (meta?.sprite) return `/sprites/${meta.sprite}`;
  if (meta?.key) return `/sprites/${meta.key}.png`;
  return "";
}

/** ---- canvas helpers (normalize computeCrops25 outputs) ---- */
async function tileToCanvas(tile) {
  if (tile && typeof tile.getContext === "function") return tile; // canvas
  if (tile && tile.data && Number.isFinite(tile.width) && Number.isFinite(tile.height)) {
    const c = document.createElement("canvas");
    c.width = tile.width;
    c.height = tile.height;
    c.getContext("2d").putImageData(tile, 0, 0);
    return c;
  }
  if (tile && tile instanceof Image) {
    const c = document.createElement("canvas");
    c.width = tile.naturalWidth || tile.width || 224;
    c.height = tile.naturalHeight || tile.height || 224;
    c.getContext("2d").drawImage(tile, 0, 0, c.width, c.height);
    return c;
  }
  if (typeof tile === "string" && tile.startsWith("data:")) {
    const img = new Image();
    const p = new Promise((res, rej) => { img.onload = () => res(img); img.onerror = rej; });
    img.src = tile;
    await p;
    return tileToCanvas(img);
  }
  return null;
}
function cropCanvas(src, x, y, w, h) {
  const c = document.createElement("canvas");
  c.width = Math.max(1, w | 0);
  c.height = Math.max(1, h | 0);
  c.getContext("2d").drawImage(src, x, y, w, h, 0, 0, c.width, c.height);
  return c;
}
function l2normFloat32(v) {
  let s = 0.0;
  for (let i = 0; i < v.length; i++) s += v[i] * v[i];
  s = Math.sqrt(s) || 1e-12;
  for (let i = 0; i < v.length; i++) v[i] = v[i] / s;
  return v;
}

/**
 * Make N crops per tile:
 * - unboardPct trims a uniform margin
 * - center + small jitter (4 directions)
 */
function makeAugCrops(baseCanvas, { unboardPct = 0.12, jitterFrac = 0.04, multiCrop = 5 } = {}) {
  const w = baseCanvas.width | 0, h = baseCanvas.height | 0;
  const mx = Math.round(w * Math.max(0, Math.min(unboardPct, 0.4)));
  const my = Math.round(h * Math.max(0, Math.min(unboardPct, 0.4)));
  let x = mx, y = my, cw = Math.max(1, w - 2 * mx), ch = Math.max(1, h - 2 * my);
  // square inside the trimmed region
  const side = Math.min(cw, ch);
  x += Math.floor((cw - side) / 2);
  y += Math.floor((ch - side) / 2);

  const j = Math.round(side * Math.max(0, Math.min(jitterFrac, 0.15)));
  const centers = [{ dx: 0, dy: 0 }];
  if (multiCrop > 1) centers.push({ dx: j, dy: 0 }, { dx: -j, dy: 0 }, { dx: 0, dy: j }, { dx: 0, dy: -j });
  const out = [];
  for (let k = 0; k < Math.min(multiCrop, centers.length); k++) {
    const { dx, dy } = centers[k];
    const cx = Math.max(0, Math.min(w - side, x + dx));
    const cy = Math.max(0, Math.min(h - side, y + dy));
    out.push(cropCanvas(baseCanvas, cx, cy, side, side));
  }
  return out;
}

/** Embed with TTA (test-time augmentation): average of crops, then L2 */
async function embedWithAug(canvas, session, aug, expectDim = 512) {
  const crops = makeAugCrops(canvas, aug);
  let acc = null;
  let used = 0;

  for (const c of crops) {
    const out = await embedImage(c, session);
    const vec =
      (out && out.data && out.data instanceof Float32Array && out.data) ||
      (out instanceof Float32Array ? out : new Float32Array(out?.data || []));
    if (!vec || !vec.length) continue;
    if (!acc) acc = new Float32Array(vec.length);
    for (let i = 0; i < vec.length; i++) acc[i] += vec[i];
    used++;
  }
  if (!acc || used === 0) return null;
  for (let i = 0; i < acc.length; i++) acc[i] /= used;
  return l2normFloat32(acc);
}

export default function useBingoCard({ card, manifest, onChange, onRemove }) {
  // --- Title / rename ---
  const [title, setTitle] = useState(card?.title || "New Card");
  const [renaming, setRenaming] = useState(false);
  const startRenaming = () => setRenaming(true);
  const commitRenaming = (nextTitle) => {
    const finalTitle = (nextTitle ?? "").trim();
    setTitle(finalTitle || "New Card");
    setRenaming(false);
    if (typeof onChange === "function") onChange({ ...(card || {}), title: finalTitle || "New Card" });
  };
  const titleEditing = {
    renaming,
    onTitleClick: startRenaming,
    onTitleInputBlur: (e) => commitRenaming(e?.currentTarget?.value ?? title),
  };
  
  // --- Grid data ---
  const [results, setResults] = useState(Array(25).fill(null));
  const [checked, setChecked] = useState(Array(25).fill(false));
  const toggleChecked = (index) =>
    setChecked((prev) => {
      const next = prev.slice();
      if (index >= 0 && index < 25) next[index] = !next[index];
      return next;
    });

  // --- Fill / analyze scaffolding ---
  const fileInputRef = useRef(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzedOnce, setAnalyzedOnce] = useState(false);
  const [progress, setProgress] = useState(0);

  // Tuner controls (session-only fractions now)
  const [showTuner, setShowTuner] = useState(false);
  const [tunerImage, setTunerImage] = useState(null);
  const [tunerImageSrc, setTunerImageSrc] = useState(null);
  const [fractions, setFractions] = useState({ left: 0, top: 0, width: 1, height: 1 });
  const [tunerFractions, setTunerFractions] = useState(null);

  // expose preview state to the crop preview modal
  if (typeof window !== "undefined") {
    window.__BINGO_PREVIEW_STATE__ = {
      getImage: () => tunerImage,
      getFractions: () =>
        tunerFractions || fractions || { left: 0, top: 0, width: 1, height: 1 },
      getTuning: () => (tuning.get?.() || {}),
    };
  }

  const pickImage = () => {
    const el = fileInputRef.current;
    if (el && typeof el.click === "function") el.click();
  };

  const onFileChange = async (e) => {
    const file = e?.target?.files?.[0];
    if (!file) return;
    try {
      setAnalyzing(false);
      setProgress(0);
      const img = await fileToImage(file);
      setTunerImage(img);
      setTunerImageSrc(img?.src || null);
      setTunerFractions(fractions || { left: 0, top: 0, width: 1, height: 1 });
      setShowTuner(true);
    } catch (err) {
      console.warn("[useBingoCard] Failed to load image:", err);
    } finally {
      if (e?.target) e.target.value = ""; // allow re-pick same file
    }
  };

  /** Confirm → crop → embed (with TTA) → match → results */
  const onTunerConfirm = async (finalFractions) => {
    const f = finalFractions || tunerFractions || fractions || { left: 0, top: 0, width: 1, height: 1 };
    setFractions(f);
    setShowTuner(false);

    // Pull current knobs from tuning store (safe defaults)
    const {
      scoreThreshold = 0.30,
      unboardPct = 0.12,
      jitterFrac = 0.04,
      multiCrop = 5,
    } = (tuning.get?.() || {});

    try {
      setAnalyzing(true);
      setProgress(5);

      // 1) Crop 25 tiles
      if (!tunerImage) throw new Error("No tuner image set");
      const rawTiles = computeCrops25(tunerImage, f);
      const canvases = [];
      for (const t of rawTiles || []) canvases.push(await tileToCanvas(t));
      const sizes = canvases.slice(0, 3).map(c => (c ? `${c.width}x${c.height}` : "null")).join(", ");
      log("[useBingoCard] crops:", canvases.length, "example sizes:", sizes);
      setProgress(15);

      // 2) CLIP session
      const session = await getClipSession();
      setProgress(30);

      // 3) Sprite index
      const index = await ensureSpriteIndex(); // { dim, count, vectors, meta, normalized:true }
      log("[useBingoCard] index shape:", { dim: index?.dim || 0, count: index?.count || 0 });
      setProgress(35);

      // 4) Embed (with TTA) & match
      const nextResults = Array(25).fill(null);
      const aug = { unboardPct, jitterFrac, multiCrop };

      for (let i = 0; i < 25; i += 1) {
        const canvas = canvases[i];
        if (!canvas) {
          nextResults[i] = { id: String(i + 1), value: "", noMatch: true };
          continue;
        }

        try {
          const vec = await embedWithAug(canvas, session, aug, index?.dim || 512);
          if (!vec) throw new Error("Empty embedding");

          if (index?.dim && vec.length !== index.dim) {
            log("[useBingoCard] embed dim vs index dim:", vec.length, index.dim);
          }

          const match = findBestMatch(vec, index, scoreThreshold);
          if (match) {
            const refMeta = match.ref || match.meta || {};
            nextResults[i] = {
              id: String(i + 1),
              value: refMeta.name || refMeta.key || "",
              match,
              spriteUrl: spriteUrlFromMeta(refMeta),
            };
          } else {
            nextResults[i] = { id: String(i + 1), value: "", noMatch: true };
          }
        } catch (err) {
          console.warn(`[useBingoCard] Embed/match failed at tile ${i}:`, err);
          nextResults[i] = { id: String(i + 1), value: "", noMatch: true };
        }

        setProgress(35 + Math.round(((i + 1) / 25) * 60));
      }

      // 5) Commit
      setResults(nextResults);
      setAnalyzedOnce(true);
      setProgress(100);
      log("[useBingoCard] done. filled results=", nextResults.filter(Boolean).length);
    } catch (err) {
      console.warn("[useBingoCard] onTunerConfirm pipeline error:", err);
    } finally {
      setAnalyzing(false);
    }
  };

  const onTunerCancel = () => {
    setShowTuner(false);
    setTunerImage(null);
    setTunerImageSrc(null);
    setTunerFractions(null);
  };

  const removeSelf = () => { if (typeof onRemove === "function") onRemove(card); };

  return {
    // Read
    title, renaming, analyzing, analyzedOnce, progress, results, checked,
    showTuner, tunerImage, tunerImageSrc, fractions, tunerFractions,

    // Actions
    startRenaming, setTitle, commitRenaming, pickImage, onFileChange,
    onTunerConfirm, onTunerCancel, setFractions, setTunerFractions,
    toggleChecked, setResults, onRemove: removeSelf,

    // Legacy bundle
    titleEditing, fileInputRef,
  };
}
